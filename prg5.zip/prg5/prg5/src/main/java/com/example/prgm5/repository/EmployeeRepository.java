package com.example.prgm5.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.prgm5.model.Employee;
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}