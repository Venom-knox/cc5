package com.example.prgm5.restcontroller;
import com.example.prgm5.model.Employee;
import com.example.prgm5.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeRepository repo;
    @GetMapping
    public List<Employee> getAll() {
        return repo.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getById(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok)
                              .orElse(ResponseEntity.notFound().build());
    }
    @PostMapping
    public Employee create(@RequestBody Employee employee) {
        return repo.save(employee);
    }
    @PutMapping("/{id}")
    public ResponseEntity<Employee> update(@PathVariable Long id, @RequestBody Employee employee) {
        return repo.findById(id).map(existing -> {
            existing.setName(employee.getName());
            existing.setAge(employee.getAge());
            existing.setEmail(employee.getEmail());
            return ResponseEntity.ok(repo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }
}