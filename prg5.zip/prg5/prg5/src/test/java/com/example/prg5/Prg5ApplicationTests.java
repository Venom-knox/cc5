package com.example.prg5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prg5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
